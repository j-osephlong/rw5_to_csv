# RW5 to CSV

Parse RW5 files into CSV files of GPS and SS records.

## Build instructions

`python -m build`

And 

`python setup.py build`