.venv/Scripts/activate;
python -m build;
python setup.py build;